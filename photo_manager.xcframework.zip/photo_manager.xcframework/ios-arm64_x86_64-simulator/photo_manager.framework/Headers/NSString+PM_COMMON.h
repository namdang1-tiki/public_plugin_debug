//
// Created by Caijinglong on 2020/3/20.
//

#import <Foundation/Foundation.h>

@interface NSString (PM_COMMON)

-(BOOL) isEmpty;

@end
