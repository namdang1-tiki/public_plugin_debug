#import <Flutter/Flutter.h>

@interface PdfViewerPlugin : NSObject<FlutterPlugin>
@end
